import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { randomBytes, scryptSync } from 'crypto';
import { Employee } from './entities/employee.entity';
import { CreateEmployeeDto } from './dto/create-employee.dto';
import { UpdateEmployeeDto } from './dto/update-employee.dto';

@Injectable()
export class EmployeesService {
  constructor(
    @InjectRepository(Employee)
    private readonly repo: Repository<Employee>,
  ) {}

  private hash(password: string): string {
    const salt = randomBytes(16).toString('hex');
    return `${salt}:${scryptSync(password, salt, 32).toString('hex')}`;
  }

  private async assertEmailFree(email: string, ignoreId?: number) {
    const existing = await this.repo.findOneBy({ email });
    if (existing && existing.id !== ignoreId) {
      throw new ConflictException('Email already in use');
    }
  }

  async create(dto: CreateEmployeeDto): Promise<Employee> {
    await this.assertEmailFree(dto.email);
    const saved = await this.repo.save(
      this.repo.create({ ...dto, password: this.hash(dto.password) }),
    );
    return this.findOne(saved.id); // re-read so password is not returned
  }

  findAll(): Promise<Employee[]> {
    return this.repo.find({ order: { id: 'ASC' } });
  }

  async findOne(id: number): Promise<Employee> {
    const employee = await this.repo.findOneBy({ id });
    if (!employee) throw new NotFoundException(`Employee ${id} not found`);
    return employee;
  }

  async update(id: number, dto: UpdateEmployeeDto): Promise<Employee> {
    const employee = await this.findOne(id);
    if (dto.email) await this.assertEmailFree(dto.email, id);
    const changes: Partial<Employee> = { ...dto };
    if (dto.password) changes.password = this.hash(dto.password);
    await this.repo.save(Object.assign(employee, changes));
    return this.findOne(id);
  }

  async remove(id: number): Promise<{ message: string }> {
    const employee = await this.findOne(id);
    await this.repo.remove(employee);
    return { message: `Employee ${id} deleted successfully` };
  }
}
