import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('employees')
export class Employee {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ unique: true })
  email: string;

  @Column()
  phone: string;

  // Dummy password; hashed on save and never returned (select: false)
  @Column({ select: false })
  password: string;

  @Column('int')
  age: number;

  @Column('int', { name: 'years_of_working' })
  yearsOfWorking: number;
}
