# Lab Task 1 – Product Management API (NestJS + TypeORM + PostgreSQL)

| SL | Name | ID | Section |
|----|------|----|---------|
| _your SL_ | _your name_ | _your ID_ | _your section_ |

## Stack
NestJS 11, TypeORM, PostgreSQL, class-validator.
Structure: `module → controller → service → entity` (+ DTOs). All DB access is in the services.

## Setup
1. Install Node.js 20+ and PostgreSQL.
2. Create the database:
   ```bash
   createdb product_management
   # or in psql: CREATE DATABASE product_management;
   ```
3. Install and configure:
   ```bash
   npm install
   cp .env.example .env     # then set DB_PASSWORD (and others) in .env
   ```
4. Run (tables are created automatically on first start):
   ```bash
   npm run start:dev
   ```
   The API runs at `http://localhost:3000`.

## Endpoints

### Products
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /products | Create a product |
| GET | /products | List all products |
| GET | /products/:id | Get one product |
| PATCH | /products/:id | Update a product |
| DELETE | /products/:id | Delete a product |

Body (POST): `{ "name": "Rice 5kg", "category": "Grocery", "price": 12.5, "quantity": 40 }`

### Employees
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /employees | Create an employee |
| GET | /employees | List all employees |
| GET | /employees/:id | Get one employee |
| PATCH | /employees/:id | Update an employee |
| DELETE | /employees/:id | Delete an employee |

Body (POST): `{ "name": "Rahim Uddin", "email": "rahim@shop.com", "phone": "01711111111", "password": "1234", "age": 30, "yearsOfWorking": 5 }`

Notes: passwords are hashed (scrypt) and never returned; email must be unique (409 otherwise);
unknown ID → 404; invalid body → 400.

## Screenshots
Postman screenshots are in `screenshots/` (01-create.png … 07-confirm-delete.png).
